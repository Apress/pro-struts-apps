README NOTES for Professional Struts Applications

1.  The code examples for this chapter was built using the following software:
	A.  MySQL-Max 3.2.3   	 	   (http://mysql.org)
        B.  OJB 9.7                  	   (http://jakarata.apache.org/ojb)
        C.  JBoss 3.0.4-Tomcat-4.1.12      (http://jboss.org)
        D.  Sun JDK 1.4            	   (http://java.sun.org)
        E.  Ant                            (http://jakarta.apache.org)
	F.  Jakarta Tomcat-4.1.12	   (http://jakarta.apache.org/tomcat)
	G.  Lucene			   (http://jakarta.apache.org/lucene)

2.  Installing MySQL
	A.  Download the MySQL-Max executable from mysql.org
	B.  Install it using the Windows-based installer
	C.  After you install it go to c:\mysql\bin and run
	     mysqld-max --standalone at the command prompt.
3.  Install the source code
	A.  Download the source file from wrox.
	B.  Unzip the file into a work directory.
	C.  Run the Ant build script using the ALL target.
	D.  Copy the distribution war file from the dist directory to your
	    your tomcat webapps directory.
4.  Notes on lucene:
    Lucene needs a directory to build its index files in. 
    There is a path in 
    the Java source file for com.wrox.javaedge.search.SearchConfiguration 
    that needs to be modified, or you can use the default /javaedge/search 
    directory for your indexes. This directory must be created before the 
    web app is run for search engine functionality.
