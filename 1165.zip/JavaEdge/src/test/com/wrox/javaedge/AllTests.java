/*
 * @(#)TestStoryCRUD.java
 *
 */
package com.wrox.javaedge;
import junit.framework.*;
/**
 * TestSuite that runs all the JUnit tests
 *
 * @version $Revision: 1.1 $
 * @author  Maciej Zawadzki
 */
public class AllTests {
    
    //**************************************************************************
    // CLASS
    //**************************************************************************
    
    //--------------------------------------------------------------------------
    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    //--------------------------------------------------------------------------
    public static Test suite() {
        TestSuite suite= new TestSuite("JavaEdge Tests");
        suite.addTestSuite(com.wrox.javaedge.member.TestMemberCRUD.class);
        suite.addTestSuite(com.wrox.javaedge.story.TestStoryCRUD.class);
        
        return suite;
    }
}