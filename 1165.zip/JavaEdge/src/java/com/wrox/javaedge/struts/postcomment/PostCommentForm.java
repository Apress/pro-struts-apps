
package com.wrox.javaedge.struts.postcomment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.Enumeration;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.wrox.javaedge.member.MemberVO;
import com.wrox.javaedge.story.StoryCommentVO;
import com.wrox.javaedge.story.StoryVO;
import com.wrox.javaedge.story.StoryManagerBD;
import com.wrox.javaedge.common.ApplicationException;

/**
 *
 * @author  John Carnell
 * @todo     Need to Javadoc this.
 */
public class PostCommentForm extends ActionForm {
    StoryCommentVO storyCommentVO = new StoryCommentVO();
    StoryVO        storyVO = new StoryVO();
    
    public ActionErrors validate(ActionMapping mapping,
    HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        
        
        return errors;
    }
    
    public void reset(ActionMapping mapping,
    HttpServletRequest request) {
    
        
        HttpSession    session  = request.getSession();
        MemberVO       memberVO = (MemberVO) session.getAttribute("memberVO");
     
    	try{
    				 
    	  String storyId = (String) request.getParameter("storyVO.storyId");
    	  
    	  System.out.println("Story id: " + storyId);
    	  StoryManagerBD storyManagerBD = new StoryManagerBD();

    	  StoryVO storyVO = (StoryVO) storyManagerBD.retrieveStory(storyId);
    	  
    	  if (storyVO==null) System.out.println("Story VO IS NULL!!!!");


    	  setStoryVO(storyVO);
    	
          StoryCommentVO storyCommentVO = new StoryCommentVO();
          storyCommentVO.setCommentAuthor(memberVO);     
          setStoryCommentVO(storyCommentVO);
    	}
    	catch(ApplicationException e){}
        
    }
    
    
    /**
     * Returns the storyCommentVO.
     * @return StoryCommentVO
     */
    public StoryCommentVO getStoryCommentVO() {
        return storyCommentVO;
    }
    
    /**
     * Sets the storyCommentVO.
     * @param storyCommentVO The storyCommentVO to set
     */
    public void setStoryCommentVO(StoryCommentVO storyCommentVO) {
        this.storyCommentVO = storyCommentVO;
    }
    
    /**
     * Returns the storyVO.
     * @return StoryVO
     */
    public StoryVO getStoryVO() {
        return storyVO;
    }
    
    /**
     * Sets the storyVO.
     * @param storyVO The storyVO to set
     */
    public void setStoryVO(StoryVO storyVO) {
        this.storyVO = storyVO;
    }
    
}
