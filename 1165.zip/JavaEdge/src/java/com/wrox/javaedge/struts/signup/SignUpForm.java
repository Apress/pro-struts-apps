package com.wrox.javaedge.struts.signup;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import com.wrox.javaedge.member.*;


/**
 *
 * @author  John Carnell
 */
public class SignUpForm extends ActionForm {
    private MemberVO memberVO = new MemberVO();
    private String confirmPassword = "";
    
    
    
    
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        
        
        return errors;
    }
    
    public void reset(ActionMapping mapping,
                      HttpServletRequest request) {
        ActionServlet servlet =  this.getServlet();
        MessageResources messageResources = servlet.getResources();
        
    }
    
    
    /**
     * Returns the confirmPassword.
     * @return String
     */
    public String getConfirmPassword() {
        return confirmPassword;
    }
    
    /**
     * Returns the memberVO.
     * @return MemberVO
     */
    public MemberVO getMemberVO() {
        return memberVO;
    }
    
    /**
     * Sets the confirmPassword.
     * @param confirmPassword The confirmPassword to set
     */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
    
    /**
     * Sets the memberVO.
     * @param memberVO The memberVO to set
     */
    public void setMemberVO(MemberVO memberVO) {
        this.memberVO = memberVO;
    }
    
}
