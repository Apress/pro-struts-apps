package com.wrox.javaedge.struts.rss;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.log4j.Logger;
import org.apache.velocity.anakia.Escape;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wrox.javaedge.story.dao.*;
import com.wrox.javaedge.common.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 *  Retrieves the top stories from JavaEdge and puts them in the session for the RSS to use.
 *  Based on HomePageSetupAction by John Carnell.
 *
 * @author  Jeff Linwood
 *
 */
public class RSSSetupAction extends Action {

    private static Logger logger = Logger.getLogger(RSSSetupAction.class);

    /** The perform() method comes from the base Struts Action class.  We
     * override this method and put the logic to carry out the user's
     * request in the overridden method
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     */
    public ActionForward perform(ActionMapping mapping,
                                    ActionForm     form,
                                    HttpServletRequest request,
                                    HttpServletResponse response) {
        
        try{
          /*
           *  Creating a Story Data Access Object and using it to retrieve
           *  the top stories.
           */
            StoryDAO storyDAO = new StoryDAO();
            Collection topStories = storyDAO.findTopStory();

          /*
           *  Putting the collection containing all of the stories into the request.
           */
            request.setAttribute("topStories", topStories);

            /*
             * Put the description into the request.
             */
            request.setAttribute("description",
                    "The hard-hitting Java journalism you demand.");

            /**
             * Put the escape object into the context
             * to escape XML entities.
             */
            request.setAttribute("escape",new Escape());

            /**
             * Create a date format to match the RSS 2.0 dates
             * Ex. Sun, 19 May 2002 15:21:36 GMT
             * http://backend.userland.com/rss
             */
            String pattern = "EEE, dd MMM yyyy HH:mm:ss z";
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);

            /**
             * Stick the date format into the request
             */
            request.setAttribute("dateFormat",dateFormat);

        } catch(DataAccessException e) {
            logger.error("Data access exception",e);
            return (mapping.findForward("system.error"));
        }
        return (mapping.findForward("rss.success"));
    }
}
