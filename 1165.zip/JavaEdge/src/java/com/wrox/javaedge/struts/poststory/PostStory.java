package com.wrox.javaedge.struts.poststory;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.wrox.javaedge.common.ApplicationException;
import com.wrox.javaedge.member.MemberVO;
import com.wrox.javaedge.story.StoryManagerBD;
import com.wrox.javaedge.story.StoryVO;
import com.wrox.javaedge.story.dao.StoryDAO;

public class PostStory extends Action {
    
    public ActionForward perform(ActionMapping mapping,
                                ActionForm     form,
                                HttpServletRequest request,
                                HttpServletResponse response){
        
        if (this.isCancelled(request)){
            System.out.println("*****The user pressed cancelled!!!");
            return (mapping.findForward("poststory.success"));
        }
        
        PostStoryForm postStoryForm = (PostStoryForm) form;

        /*Uncomment for the dynamic form example*/
        //org.apache.struts.action.DynaActionForm postStoryForm = (org.apache.struts.action.DynaActionForm) form;
        
        HttpSession session = request.getSession();
        
        MemberVO      memberVO      = (MemberVO) session.getAttribute("memberVO");
        
        try{
            StoryVO storyVO = new StoryVO();
            
            storyVO.setStoryIntro(postStoryForm.getStoryIntro());
            storyVO.setStoryTitle(postStoryForm.getStoryTitle());
            storyVO.setStoryBody(postStoryForm.getStoryBody());
            
            //Uncomment for the dynamic form example
            /*storyVO.setStoryIntro((String)postStoryForm.get("storyIntro"));
            storyVO.setStoryTitle((String)postStoryForm.get("storyTitle"));
            storyVO.setStoryBody((String)postStoryForm.get("storyBody"));*/

            storyVO.setStoryAuthor(memberVO);
            storyVO.setSubmissionDate(new java.sql.Date(System.currentTimeMillis()));
            storyVO.setComments(new Vector());
            
            StoryManagerBD storyManager = new StoryManagerBD();
            storyManager.addStory(storyVO);
            
            
            System.out.println("****I am done with post story******");
        }
        catch(Exception e){
            System.err.println("An application exception has been raised in PostStory.perform(): " + e.toString());
            return (mapping.findForward("system.failure"));
        }
        
        return (mapping.findForward("poststory.success"));
    }
}



