/*
 * PostStorySetupAction.java
 *
 * Created on September 15, 2002, 8:15 PM
 */

package com.wrox.javaedge.struts.poststory;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wrox.javaedge.member.*;
import com.wrox.javaedge.member.dao.*;
import com.wrox.javaedge.common.*;
import java.util.*;

/**
 *
 * @author  John Carnell
 */
public class PostStorySetupAction extends Action {

    public ActionForward perform(ActionMapping mapping,
                                ActionForm     form,
                                HttpServletRequest request,
                                HttpServletResponse response){
        
        return (mapping.findForward("poststory.success"));
    }
}
