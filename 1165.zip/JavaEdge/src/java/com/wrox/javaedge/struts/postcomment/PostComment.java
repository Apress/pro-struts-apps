package com.wrox.javaedge.struts.postcomment;

import org.apache.struts.action.*;
import com.wrox.javaedge.member.*;
import com.wrox.javaedge.story.*;
import com.wrox.javaedge.common.*;
import javax.servlet.http.*;

/**
 * @author Administrator
 *
 *@todo     Need to explore how we can use XDoclet to generate
 * 		    our Struts information.  
 *@todo     Need to JavaDoc this information. 
 */
public class PostComment extends Action {
	// Create Log4j category instance for logging
	   static private org.apache.log4j.Category log = org.apache.log4j.Category.getInstance(PostComment.class.getName());
	   
	    public ActionForward perform(ActionMapping mapping, 
                                 ActionForm     form,
                                 HttpServletRequest request,
                                 HttpServletResponse response){
        
        if (this.isCancelled(request)){
           System.out.println("*****The user pressed cancelled!!!");
           return (mapping.findForward("poststory.success"));
        }
                                     
        PostCommentForm postCommentForm = (PostCommentForm) form;
        HttpSession session = request.getSession();
        
        MemberVO      memberVO      = (MemberVO) session.getAttribute("memberVO");
        String        storyId       = (String) request.getParameter("storyVO.storyId");
        
        try{
          StoryManagerBD storyManagerBD = new StoryManagerBD();
          StoryVO storyVO = storyManagerBD.retrieveStory(storyId);
          
          StoryCommentVO storyCommentVO = postCommentForm.getStoryCommentVO();
          storyCommentVO.setCommentAuthor(memberVO);
          storyCommentVO.setSubmissionDate(new java.sql.Date(System.currentTimeMillis()));
          storyVO.getComments().add(storyCommentVO);
          storyManagerBD.updateStory(storyVO);         
        }
        catch(ApplicationException e){
          log.info("*******Application Exception thrown in PostComment.perform(): " + e.toString());
          e.printStackTrace();
          return (mapping.findForward("system.failure")); 
        }        
       
       
       
        return (mapping.findForward("postcomment.success"));
    }
}
