package com.wrox.javaedge.struts.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.wrox.javaedge.member.MemberVO;

public class Logout extends Action {
	
	public ActionForward perform(ActionMapping mapping,
								   ActionForm     form,
								   HttpServletRequest request,
								   HttpServletResponse response){

         /*Removing the membervo from the session, the filter should pick
           this up and lookup the default record.*/ 
          HttpSession session = request.getSession();
          session.removeAttribute("memberVO");
 
          MemberVO memberVO = (MemberVO) session.getAttribute("memberVO");

          if (memberVO==null) System.out.println("MEMBERVO IS NULL");
	  return (mapping.findForward("logout.success"));							   
	}

}
