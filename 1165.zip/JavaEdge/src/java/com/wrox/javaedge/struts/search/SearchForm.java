package com.wrox.javaedge.struts.search;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

/**
 * @author Jeff Linwood
 *
 * The form class for the Search page
 */
public class SearchForm extends ActionForm {

	protected String query = "";

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        
        
        return errors;
    }
    
    public void reset(ActionMapping mapping,
                      HttpServletRequest request) {
        ActionServlet servlet =  this.getServlet();
        MessageResources messageResources = servlet.getResources();
        
    }
    
    /** Getter for property query.
     * @return Value of property query.
     */
    public String getQuery() {
        return query;
    }
    
    /** Setter for property query.
     * @param query New value of property query.
     */
    public void setQuery(String query) {
        this.query = query;
    }    

}
