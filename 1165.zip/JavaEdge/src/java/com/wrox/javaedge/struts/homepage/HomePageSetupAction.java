package com.wrox.javaedge.struts.homepage;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;

import com.wrox.javaedge.story.*;
import com.wrox.javaedge.story.dao.*;
import com.wrox.javaedge.common.*;
import java.util.*;

/**
 *  Retrieves the top ten posting on JavaEdge.
 * @author  John Carnell
 * @todo     Need to explore how we can use XDoclet to generate
 * 			 our Struts information.  Do we want to demonstrate this?
 */
public class HomePageSetupAction extends Action {
    
    /** The perform() method comes from the base Struts Action class.  We
     * override this method and put the logic to carry out the user's
     * request in the overrident method
     * @param mapping An ActionMapping class that will be used by the Action class to tell
     * the ActionServlet where to send the end-user.
     *
     * @param form The ActionForm class that will contain any data submitted
     * by the end-user via a form.
     * @param request A standard Servlet HttpServletRequest class.
     * @param response A standard Servlet HttpServletResponse class.
     * @return An ActionForward class that will be returned to the ActionServlet indicating where
     *         the user is to go next.
     */
    public ActionForward perform(ActionMapping mapping,
                                    ActionForm     form,
                                    HttpServletRequest request,
                                    HttpServletResponse response) {
        
        try{
            
          /*
           *  Creating a Story Data Access Object and using it to retrieve
           *  all of the top stories.
           */
            System.out.println("******I AM IN HOMEPAGE SETUP ACTION CALL********");
            StoryDAO storyDAO = new StoryDAO();
            System.out.println("Hello world!");
            Collection topStories = storyDAO.findTopStory();
            System.out.println("******Done with  HOMEPAGESETUP********");
            
          /*
           *  Putting the collection containing the top stories into the
           *  request
           */
            request.setAttribute("topStories", topStories);
        } catch(DataAccessException e) {
            System.out.println("Data access exception raised in HomePageSetupAction.perform()");
            e.printStackTrace();
            return (mapping.findForward("system.error"));
        }
        
        return (mapping.findForward("homepage.success"));
    }
}
