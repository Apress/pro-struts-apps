package com.wrox.javaedge.struts.login;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionServlet;

import com.wrox.javaedge.member.*;
import com.wrox.javaedge.common.*;

/**
 * @author jcarnell
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class LoginForm extends ActionForm {
	
	private String userId = "";
	private String password ="";
	
	public ActionErrors validate(ActionMapping mapping,
								 HttpServletRequest request) {
	  ActionErrors errors = new ActionErrors();
	  
	  MemberManagerBD memberManagerBD = new MemberManagerBD();
	  MemberVO        memberVO        = null;
	  HttpSession     session         = request.getSession();
	  
	  try{
	    memberVO = memberManagerBD.validateUserId(getUserId(), getPassword());
	  }
	  catch(ApplicationException e){}
	  
	  
	  if (memberVO==null){
	  	ActionError error = new ActionError("error.header.invalidlogin");
	  	errors.add("invalid.login", error);
	  }
	  else{
	    session.setAttribute("memberVO",memberVO);
	  }
	  
	  return errors;

	}
	
	public void reset(ActionMapping mapping,
						 HttpServletRequest request) {
	  setUserId("");
	  setPassword("");
						 	
	}
	
	/**
	 * Returns the password.
	 * @return String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Returns the userId.
	 * @return String
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the password.
	 * @param password The password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Sets the userId.
	 * @param userId The userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

}
