package com.wrox.javaedge.struts.search;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wrox.javaedge.member.*;
import com.wrox.javaedge.member.dao.*;
import com.wrox.javaedge.common.*;
import java.util.*;

/**
 *	Sets up any needed properties for the search form. Forwards user to the
 * 	@author  Jeff Linwood
 */
public class SearchFormSetupAction extends Action {
	
	/**
	 * Performs no work for the action
	 * 
	 */
    public ActionForward perform(ActionMapping mapping,
                                ActionForm     form,
                                HttpServletRequest request,
                                HttpServletResponse response){     
         
        return (mapping.findForward("search.success"));
    }
}
