package com.wrox.javaedge.struts.signup;

import org.apache.struts.action.*;
import com.wrox.javaedge.member.*;
import com.wrox.javaedge.member.dao.*;
import com.wrox.javaedge.common.*;
import javax.servlet.http.*;
/**
 * @author Administrator
 *
 *  This is a very rudimentary sign up class.  It just inserts
 *  whatever member data the user has entered.  You could as an 
 *  exercise build out the SignUpForm class to do some actual data 
 *  validation.
 */
public class SignUp extends Action {
    
    public ActionForward perform(ActionMapping mapping, 
                                 ActionForm     form,
                                 HttpServletRequest request,
                                 HttpServletResponse response){

        SignUpForm signUpForm = (SignUpForm) form;
        
        MemberVO memberVO = signUpForm.getMemberVO();
        HttpSession session = request.getSession();
        
        session.setAttribute("memberVO", memberVO);
        
        try{
          MemberDAO memberDAO = new MemberDAO();
          memberDAO.insert(memberVO);
        }
        catch(DataAccessException e){
          System.err.println("A dataaccess exception has been raised in SignUp.perform(): " + e.toString());           
          return (mapping.findForward("system.failure"));
        }
        
        
        return (mapping.findForward("signup.success"));
        
        
    }

	
}
