package com.wrox.javaedge.struts.storydetail;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;

import com.wrox.javaedge.story.*;
import com.wrox.javaedge.story.dao.*;
import com.wrox.javaedge.common.*;
import java.util.*;

/**
 *
 * @author  John Carnell
 */
public class StoryDetailSetupAction extends Action {
    
    
    public ActionForward perform(ActionMapping mapping,
                                    ActionForm     form,
                                    HttpServletRequest request,
                                    HttpServletResponse response){
        
        String storyId = request.getParameter("storyId");
        
        try{
            StoryDAO storyDAO = new StoryDAO();
            StoryVO storyVO = (StoryVO) storyDAO.findByPK(storyId);
            
            if (storyVO==null)
                System.out.println("StoryVO IS NULL!");
            else
                System.out.println("StoryVO IS NOT NULL");
            
            request.setAttribute("storyVO",storyVO);
            request.setAttribute("comments", storyVO.getComments());
        }
        catch(DataAccessException e){
            System.out.println(e.toString());
        }
        
        
        
        System.out.println("The Story Id is: " + storyId);
        
        return (mapping.findForward("storydetail.success"));
    }
}
