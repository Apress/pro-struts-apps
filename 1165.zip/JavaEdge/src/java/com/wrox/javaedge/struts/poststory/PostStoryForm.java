/*
 * PostStoryForm.java
 *
 * Created on September 15, 2002, 9:04 PM
 */

package com.wrox.javaedge.struts.poststory;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import com.wrox.javaedge.common.VulgarityFilter;


/**
 *
 * @author  John Carnell
 */
public class PostStoryForm extends ActionForm {
    
    
    String storyTitle = "";
    String storyIntro = "";
    String storyBody  = "";
    
    //Checks to make sure field being checked is not null
    private void checkForEmpty(String fieldName, String fieldKey, String value, ActionErrors errors){
        if (value.trim().length()==0){
          ActionError error = new ActionError("error.poststory.field.null", fieldName);
          errors.add(fieldKey, error);
        }
    }
    
    //Checks to make sure the field being checked does not violate our vulgarity list
    private void checkForVulgarities(String fieldName, String fieldKey, String value, ActionErrors errors){
       VulgarityFilter filter = VulgarityFilter.getInstance();
        
        if (filter.isOffensive(value)){
          ActionError error = new ActionError("error.poststory.field.vulgar", fieldName);
          errors.add(fieldKey, error);
        }
    }
    
    //Checks to make sure the field in question does not exceed a maximum length
    private void checkForLength(String fieldName, String fieldKey, String value, int maxLength, ActionErrors errors){
        if (value.length()>maxLength){
          ActionError error = new ActionError("error.poststory.field.length", fieldName);
          errors.add(fieldKey, error);  
        }      
    }
    
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {
       ActionErrors errors = new ActionErrors();
       
       checkForEmpty("Story Title", "error.storytitle.empty", getStoryTitle(),errors);
       checkForEmpty("Story Intro", "error.storyintro.empty", getStoryIntro(), errors);
       checkForEmpty("Story Body",  "error.storybody.empty", getStoryBody(), errors);
       
       checkForVulgarities("Story Title", "error.storytitle.vulgarity", getStoryTitle(), errors);
       checkForVulgarities("Story Intro", "error.storyintro.vulgarity", getStoryIntro(), errors);
       checkForVulgarities("Story Body",  "error.storybody.vulgarity", getStoryBody(), errors);
       
       checkForLength("Story Title", "error.storytitle.length", getStoryTitle(), 100, errors);
       checkForLength("Story Intro", "error.storyintro.length", getStoryIntro(), 2048, errors);
       checkForLength("Story Body", "error.storybody.length", getStoryBody(),  10000, errors);
       
       return errors;
    }
    
    public void reset(ActionMapping mapping,
                      HttpServletRequest request) {  
      ActionServlet servlet =  this.getServlet();
      MessageResources messageResources = servlet.getResources();

      storyTitle = messageResources.getMessage("javaedge.poststory.title.instructions");
      storyIntro = messageResources.getMessage("javaedge.poststory.intro.instructions");
      storyBody  = messageResources.getMessage("javaedge.poststory.body.instructions");  
    }
    
    /** Getter for property storyTitle.
     * @return Value of property storyTitle.
     */
    public java.lang.String getStoryTitle() {
        return storyTitle;
    }
    
    /** Setter for property storyTitle.
     * @param storyTitle New value of property storyTitle.
     */
    public void setStoryTitle(java.lang.String storyTitle) {
        this.storyTitle = storyTitle;
    }
    
    /** Getter for property storyIntro.
     * @return Value of property storyIntro.
     */
    public java.lang.String getStoryIntro() {
        return storyIntro;
    }
    
    /** Setter for property storyIntro.
     * @param storyIntro New value of property storyIntro.
     */
    public void setStoryIntro(java.lang.String storyIntro) {
        this.storyIntro = storyIntro;
    }
    
    /** Getter for property storyBody.
     * @return Value of property storyBody.
     */
    public java.lang.String getStoryBody() {
        return storyBody;
    }
    
    /** Setter for property storyBody.
     * @param storyBody New value of property storyBody.
     */
    public void setStoryBody(java.lang.String storyBody) {
        this.storyBody = storyBody;
    }
}
