package com.wrox.javaedge.struts.postcomment;

import org.apache.struts.action.*;
import javax.servlet.http.*;

import com.wrox.javaedge.common.*;
import com.wrox.javaedge.story.*;
import com.wrox.javaedge.story.dao.*;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PostCommentSetupAction extends Action {
    
    public ActionForward perform(ActionMapping mapping,
                                    ActionForm     form,
                                    HttpServletRequest request,
                                    HttpServletResponse response){
        
  
        return (mapping.findForward("postcomment.success"));
        
    }
    
    
}
