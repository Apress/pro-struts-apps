package com.wrox.javaedge.search;

import java.io.IOException;
import java.util.*;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.log4j.Category;

import com.wrox.javaedge.common.DataAccessException;
import com.wrox.javaedge.story.StoryVO;
import com.wrox.javaedge.story.dao.StoryDAO;

/**
 * Adds stories and comments from JavaEdge to Lucene's index.
 * 
 * Gets a list of all stories from the story object.  Transforms those
 * stories and the related comments into Document objects for Lucene.
 * Uses Lucene's IndexWriter to add them to Lucene's index.
 * 
 * @author Jeff Linwood
 * 
 */
public class IndexContent {

    // Create Log4j category instance for logging
    static private Category log = Category.getInstance(
    		IndexContent.class.getName());
    		
	/**
	 * Get a copy of the writer we use to add entries to the index
	 * Uses the standard analyzer.
	 * 
	 * @return an IndexWriter that points to the configured Lucene index.
	 */
	public IndexWriter getWriter() throws IOException {
		      
      	Analyzer analyzer = new StandardAnalyzer();
        IndexWriter writer;

		//check to see if an index already exists
        if (IndexReader.indexExists(SearchConfiguration.getIndexPath())) {
            writer = new IndexWriter(SearchConfiguration.getIndexPath(),
								 analyzer, false);
        }
        else {
            writer = new IndexWriter(SearchConfiguration.getIndexPath(),
								 analyzer, true);
        }


		return writer;
	}

	/**
	 * Get a copy of the reader we use to get entries from the index
     *
	 * @return an IndexReader that points to the configured Lucene index.
	 */
	public IndexReader getReader() throws IOException {

        IndexReader reader = IndexReader.open(SearchConfiguration.getIndexPath());
		return reader;
	}

	/**
	 * Get a writer, get the stories, convert each story to a Lucene Document.
	 * add to index, close index.
	 * 
	 */
	
	public void createIndex() {
		try {
			
			// Lucene's index generator
			IndexWriter writer = getWriter();

            //Lucene's index reader
            IndexReader reader = getReader();

            //set up our analyzer
            Analyzer analyzer = new StandardAnalyzer();

            //set up our searcher
            String indexPath = SearchConfiguration.getIndexPath();
            Searcher searcher = new IndexSearcher(indexPath);

			//from the DAO
			Collection stories = getAllStories();
			if (stories == null) {
				return;	
			}
			
			//Easier to use an iterator for retrieving the stories
			Iterator iter = stories.iterator();
			while (iter.hasNext()) {

				//this could throw a class cast exception
				StoryVO story = (StoryVO) iter.next();
				
				//we wrote the Document Conversion Tool specifically for the
				//story value objects
				Document doc = DocumentConversionTool.createDocument(story);

                //get out the content field
                String content = doc.getField(DocumentConversionTool.CONTENT_FIELD).stringValue();

                //get the search entry for this story id
                //create a query that looks up items by our searchId
                Query query = QueryParser.parse(story.getStoryId().toString(),
                                "storyId",
                                analyzer);

                //get all of the hits for the query term out of the index
                Hits hits = searcher.search(query);

                //should only have one or zero entries for each story id, otherwise log a warning
                if (hits.length() == 0) {

                    //this story is brand new
                    //add the converted document to the lucene index
                    writer.addDocument(doc);
                    log.info("new story added: " + story.getStoryId());
                }
                else if (hits.length() == 1) {
                    log.info("story is old: " + story.getStoryId());
                    //get the entry out of the search engine
                    Document oldDoc = hits.doc(0);

                    //get the old content
                    String oldContent = oldDoc.getField(
                            DocumentConversionTool.CONTENT_FIELD).stringValue();

                    //if it has been updated, delete it from the index, then re-add it.
                    if (!content.equals(oldContent)) {
                        log.info("story is being updated: " + story.getStoryId());
                        reader.delete(new Term("storyId",story.getStoryId().toString()));
                        writer.addDocument(doc);
                    }
                }
                else {
                    log.warn("Wrong number of entries for story id: " + story.getStoryId()
                            + ": " + hits.length() + " found." );
                }

			}

			closeWriter(writer);
		}
		catch (IOException ie) {
			log.error ("Error creating Lucene index: " + ie.getMessage(),ie);
		}
		catch (ClassCastException cce) {
			log.error ("Error casting object to StoryVO: " + cce.getMessage(),cce);
		}
        catch (ParseException pe) {
            log.error ("Error parsing Lucene query for storyId: " + pe.getMessage(),pe);
        }
	}
	
	/**
	 * Make a call out to the DAO to get all the stories
	 * 
	 * @return a Collection of StoryVO objects
	 */
	public Collection getAllStories() {
		try {
			
			StoryDAO storyDAO = new StoryDAO();
		
			return storyDAO.findAllStories();	
		}
		catch (DataAccessException dae) {
			log.error("Error retrieving all stories from DAO: " + dae.getMessage(),
						dae);								
		}
		return null;
	}
	
	/**
	 * Close down the writer, after running the index optimizer.
	 * 
	 * @param writer An open IndexWriter
	 */
	public void closeWriter(IndexWriter writer) throws IOException {		
    	if (writer == null) {
    		return;
    	}
      	writer.optimize();
      	writer.close();		
	}
}
