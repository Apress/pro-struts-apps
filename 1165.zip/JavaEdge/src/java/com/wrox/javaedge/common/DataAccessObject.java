/*
 * DataAccessObject.java
 *
 * Created on August 24, 2002, 5:23 PM
 */

package com.wrox.javaedge.common;

public interface DataAccessObject {
    public  ValueObject findByPK(String primaryKey) throws DataAccessException;
    public  void insert(ValueObject insertRecord) throws DataAccessException;
    public  void update(ValueObject updateRecord) throws DataAccessException;
    public  void delete(ValueObject deleteRecord) throws DataAccessException;
}
