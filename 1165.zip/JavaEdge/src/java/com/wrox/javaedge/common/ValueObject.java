/*
 * ValueObject.java
 *
 * Created on August 24, 2002, 5:40 PM
 */

package com.wrox.javaedge.common;

/**
 *
 * @author  John Carnell
 */
public abstract class ValueObject {
    
    /** Creates a new instance of ValueObject */
    public ValueObject() {
    }
    
}
