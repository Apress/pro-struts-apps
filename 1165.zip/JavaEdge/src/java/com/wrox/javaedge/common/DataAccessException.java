/*
 * DataAccessException.java
 *
 * Created on August 24, 2002, 5:37 PM
 */

package com.wrox.javaedge.common;

/**
 *
 * @author  John Carnell
 * @todo     Need to Javadoc this
 */
public class DataAccessException extends Exception {
    Throwable exceptionCause = null;
    
    
    /** Creates a new instance of DataAccessException */
    public DataAccessException(String exceptionMsg) {
        super(exceptionMsg);
    }
    
    public DataAccessException(String exceptionMsg, Throwable exception){
       super(exceptionMsg);   
       exceptionCause = exception;
    }
    
    public void printStackTrace(){
        if (exceptionCause!=null){
           System.err.println("An exception has been caused by: ");
           exceptionCause.printStackTrace();
        }
        
    }
    
    
    
}
