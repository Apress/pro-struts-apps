package com.wrox.javaedge.member;

import java.util.*;
import com.wrox.javaedge.common.*;

/**
 * Wrapper around data retrieved from the member table.
 * 
 * @author John Carnell
 * @author Maciej Zawadzki
 */
public class MemberVO extends ValueObject implements java.io.Serializable{
    
    private Long memberId;
    private String firstName;
    private String lastName;    
    private String userId;
    private String password;
    private String email;
    
    
    
    public MemberVO(){}
    
    /**
     * @param email
     * @param firstName
     * @param lastName
     * @param memberId
     * @param password
     * @param stories
     * @param userId  */    
    public MemberVO(String email,
    String firstName,
    String lastName,
    Long memberId,
    String password,
    String   userId){
        this.email = email;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.memberId  = memberId;
        this.password  = password;
        this.userId    = userId;
        
    }
    
    ///////////////////////////////////////
    // access methods for attributes
    
    /**
     * @return first name */    
    public String getFirstName() {
        return firstName;
    }
    /**
     * @param firstName  */    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * @return last name */    
    public String getLastName() {
        return lastName;
    }
    /**
     * @param lastName  */    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /**
     * @return user Id */    
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId  */    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return password */    
    public String getPassword() {
        return password;
    }
    /**
     * @param password  */    
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * @return email */    
    public String getEmail() {
        return email;
    }
    /**
     * @param email  */    
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return member Id */    
    public Long getMemberId() {
        return memberId;
    }
    /**
     * @param memberId  */    
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }    
    
    //--------------------------------------------------------------------------
    public String toString() {
        String result = "MemberVO [";
        result += "memberId: " + memberId;
        result += ", firstName: " + firstName;
        result += ", lastName: " + lastName;    
        result += ", userId: " + userId;
        result += ", password: " + password;
        result += ", email: " + email;
        result += "]";
        
        return result;
    }
    
} // end MemberVO



