/*
 * MemberDAO.java
 *
 * Created on August 24, 2002, 5:25 PM
 */

package com.wrox.javaedge.member.dao;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryByCriteria;

import com.wrox.javaedge.common.DataAccessException;
import com.wrox.javaedge.common.DataAccessObject;
import com.wrox.javaedge.common.ServiceLocator;
import com.wrox.javaedge.common.ServiceLocatorException;
import com.wrox.javaedge.common.ValueObject;
import com.wrox.javaedge.member.MemberVO;

/**
 *  This   class is responsible for handling all CRUD logic associated with the
 *  member   table in the MemberDAO database.
 * 
 * @todo Need to implement this class as a singleton.
 *
 */
public class MemberDAO implements DataAccessObject { 
    
	// Create Log4j category instance for logging
    static private org.apache.log4j.Category log = org.apache.log4j.Category.getInstance(MemberDAO.class.getName());
		
	/**
     * Deletes a single member record from the JavaEdge database.
     * @see com.wrox.javaedge.common.DataAccessObject#delete(com.wrox.javaedge.common.ValueObject)
     */    
    public void delete(ValueObject deleteRecord) throws DataAccessException {
    	log.info("***********************Entering MemberDAO.delete()***********************");
    	PersistenceBroker broker = null;

    			try{
    				broker = ServiceLocator.getInstance().findBroker();
    				MemberVO memberVO = (MemberVO) deleteRecord;

    				//Begin the transaction.
    				broker.beginTransaction();
    				  broker.delete(memberVO);
    				broker.commitTransaction();
    			}
    			catch (PersistenceBrokerException e){
    				// if something went wrong: rollback
    				broker.abortTransaction();
    				log.error("PersistenceBrokerException thrown in MemberDAO.delete(): " + e.toString());
    				e.printStackTrace();

    				throw new DataAccessException("Error in MemberVO.delete()",e);
    			}
    			catch(ServiceLocatorException e){
    			  log.error("ServiceLocatorException thrown in MemberDAO.delete(): " + e.toString());	
    			  throw new DataAccessException("ServiceLocator exception in MemberVO.delete()",e);
    			}
    			finally{
    			  if (broker!=null) broker.close();
    			}
    	log.info("***********************Leaving MemberDAO.delete()***********************");
    }
    
    
	/**
     * Finds a single member record, as specified by the primary key value
     * passed in.  If no record is found a null value is returned.
     * 
	 * @see com.wrox.javaedge.common.DataAccessObject#findByPK(java.lang.String)
	 */
	public ValueObject findByPK(String primaryKey) throws DataAccessException {
		log.info("***********************Entering MemberDAO.findByPK()***********************");
    	PersistenceBroker broker = null;
    	MemberVO memberVO   = null;
    	
    	try{
    	  broker = ServiceLocator.getInstance().findBroker();
          memberVO = new MemberVO();
          memberVO.setMemberId(new Long(primaryKey));
        
          Query query = new QueryByCriteria(memberVO);
          memberVO = (MemberVO) broker.getObjectByQuery(query);
    	}
    	catch(ServiceLocatorException e){
    		log.error("ServiceLocatorException thrown in MemberDAO.findByPK(): " + e.toString());
    	   throw new DataAccessException("ServiceLocatorException in MemberDAO.findByPK()",e);	
    	}
    	finally{
    	  if (broker!=null) broker.close();	
    	}
        
		log.info("***********************Leaving MemberDAO.findByPK()***********************");
        return memberVO;
    }
    
    public ValueObject findByCriteria(MemberVO memberVO) throws DataAccessException{
    	log.info("***********************Entering MemberDAO.findByCriteria()***********************");
    		PersistenceBroker broker = null;
    		MemberVO returnVO   = null;

    		try{
    		  broker = ServiceLocator.getInstance().findBroker();
    		  returnVO = new MemberVO();

    		  Query query = new QueryByCriteria(memberVO);
    		  returnVO = (MemberVO) broker.getObjectByQuery(query);
    		}
    		catch(ServiceLocatorException e){
    			log.error("ServiceLocatorException thrown in MemberDAO.findByCriteria(): " + e.toString(),e);
    		   throw new DataAccessException("ServiceLocatorException in MemberDAO.findByCriteria()",e);
    		}
    		finally{
    		  if (broker!=null) broker.close();
    		}

    		log.info("***********************Leaving MemberDAO.findByCriteria()***********************");
    		return returnVO;
    }

    /**
     * Inserts a single member into the member table.  The value object passed
     * in has to be of type MemberVO.
     * 
	 * @see com.wrox.javaedge.common.DataAccessObject#insert(com.wrox.javaedge.common.ValueObject)
	 */
	public void insert(ValueObject insertRecord) throws DataAccessException {
	  log.info("***********************Entering MemberDAO.insert()***********************");	
      MemberVO memberVO = null;
      PersistenceBroker broker = null;
      
       try{
       	    broker = ServiceLocator.getInstance().findBroker();
            memberVO = (MemberVO) insertRecord; 
                       
            broker.beginTransaction();
              broker.store(memberVO);
            broker.commitTransaction();
        }
        catch(ServiceLocatorException e){
        	log.error("ServiceLocatorException thrown in MemberDAO.insert(): " + e.toString());
            throw new DataAccessException("ServiceLocator in Error in MemberDAO.insert()",e);	
        }
        catch (PersistenceBrokerException e){
            // if something went wrong: rollback
            broker.abortTransaction();
            e.printStackTrace();
            
        	log.error("PersistenceBrokerException thrown in MemberDAO.insert(): " + e.toString());
            throw new DataAccessException("Error in MemberDAO.insert()",e);
        }
        finally{
          if (broker!=null) broker.close();
        }
        
		log.info("***********************Leaving MemberDAO.insert()***********************");	
    }

    /**
     * Updates a single member record in the JavaEdge database.
	 * @see com.wrox.javaedge.common.DataAccessObject#update(com.wrox.javaedge.common.ValueObject)
	 */
    public void update(ValueObject updateRecord) throws DataAccessException {
    	log.info("***********************Entering MemberDAO.update()***********************");
    	MemberVO memberVO = null;
    	PersistenceBroker broker = null;

    	 try{
    		  broker = ServiceLocator.getInstance().findBroker();
    		  memberVO = (MemberVO) updateRecord;

    		  broker.beginTransaction();
    			broker.store(memberVO);
    		  broker.commitTransaction();
    	  }
    	  catch(ServiceLocatorException e){
    	  	  log.error("ServiceLocatorException thrown in MemberDAO.update(): " + e.toString());
    		  throw new DataAccessException("ServiceLocator in Error in MemberDAO.update()",e);
    	  }
    	  catch (PersistenceBrokerException e){
    		  // if something went wrong: rollback
    		  broker.abortTransaction();
    	  	  log.error("PersistenceBrokerException thrown in MemberDAO.update(): " + e.toString());
    		  e.printStackTrace();

    		  throw new DataAccessException("Error in MemberDAO.update()",e);
    	  }
    	  finally{
    		if (broker!=null) broker.close();
    	  }
    	  
    	log.info("***********************Entering MemberDAO.update()***********************");
    }
}
