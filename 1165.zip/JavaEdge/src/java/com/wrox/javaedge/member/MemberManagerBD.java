package com.wrox.javaedge.member;

import com.wrox.javaedge.member.*;
import com.wrox.javaedge.member.dao.*;
import com.wrox.javaedge.common.*;
/**
 * @author jcarnell
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class MemberManagerBD {
	// Create Log4j category instance for logging
    static private org.apache.log4j.Category log = org.apache.log4j.Category.getInstance(MemberManagerBD.class.getName());
	
	public MemberVO validateUserId(String userId, String password) throws ApplicationException{
		MemberVO memberVO = new MemberVO();
		
		memberVO.setUserId(userId);
		memberVO.setPassword(password);
		
		MemberManagerBD memberManagerBD = new MemberManagerBD();
		
		MemberDAO memberDAO = new MemberDAO();
		
		try{
		  memberVO = (MemberVO) memberDAO.findByCriteria(memberVO);
		}
		catch(DataAccessException e){
		  log.error("Error in MemberManagerBD.validateUserId(): " + e.toString(),e);
		  throw new ApplicationException("Error in MemberManagerBD.validateUserId(): " + e.toString(),e);	
		}
		
		return memberVO;
	}	

}
