package com.wrox.javaedge.story.ejb;

import com.wrox.javaedge.member.*;

public class PrizeManager{
  public void notifyMarketing(MemberVO memberVO, int totalCount){
     System.out.println("The prize manager has been invoked for member: " +
                        memberVO.getFirstName() + " " + memberVO.getLastName() +                        " for a count of " + totalCount + " submissions.");
  }
 
  public int checkStoryCount(MemberVO memberVO){
    return 0;
  }

}
