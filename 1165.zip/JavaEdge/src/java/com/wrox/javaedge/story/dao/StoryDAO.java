/*
 * StoryDAO.java
 *
 * Created on August 24, 2002, 7:01 PM
 */

package com.wrox.javaedge.story.dao;

import java.util.Collection;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.apache.ojb.broker.query.QueryFactory;

import com.wrox.javaedge.common.DataAccessException;
import com.wrox.javaedge.common.DataAccessObject;
import com.wrox.javaedge.common.ServiceLocator;
import com.wrox.javaedge.common.ServiceLocatorException;
import com.wrox.javaedge.common.ValueObject;
import com.wrox.javaedge.story.StoryVO;

/**
 *
 * StoryDAO is responsible for all CRUD logic associated with stories.
 *
 * @todo JCC - Need to implement this class as a singleton.
 */
public class StoryDAO implements DataAccessObject {
    public static final int MAXIMUM_TOPSTORIES = 11;
    
    // Create Log4j category instance for logging
    static private org.apache.log4j.Category log = org.apache.log4j.Category.getInstance(StoryDAO.class.getName());
    
    /**
     * Finds a single Story record by a story id passed into the method.
     * @see com.wrox.javaedge.common.DataAccessObject#findByPK(java.lang.String)
     */
    public ValueObject findByPK(String primaryKey) throws DataAccessException {
        log.info("************Entering the StoryDAO.findByPK***************");
        PersistenceBroker broker = null;
        StoryVO storyVO = null;
        
        try {
            broker = ServiceLocator.getInstance().findBroker();
            storyVO = new StoryVO();
            storyVO.setStoryId(new Long(primaryKey));
            
            Query query = new QueryByCriteria(storyVO);
            storyVO = (StoryVO) broker.getObjectByQuery(query);
        } catch (ServiceLocatorException e) {
            log.error("PersistenceBrokerException thrown in StoryDAO.findByPK(): " + e.toString());
            throw new DataAccessException("Error in StoryDAO.findByPK(): " + e.toString(),e);
        } finally {
            if (broker != null)
                broker.close();
        }
        
        log.info("************Done with the StoryDAO.findByPK()***************");
        return storyVO;
    }
    
    
    /**
     * Returns a collection of the top latest stories.  The number of records to
     * be returned are controlled by the MAXIMUM_TOPSTORIES constant on this
     * class.
     * @return Collection
     * @throws DataAccessException
     */
    public Collection findTopStory() throws DataAccessException {
        log.info("************Entering with the StoryDAO.findTopStory()***************");
        PersistenceBroker broker = null;
        Collection results = null;
        
        Criteria criteria = new Criteria();
        criteria.addOrderByDescending("storyId");
        
        Query query = QueryFactory.newQuery(StoryVO.class, criteria);
        
        query.setStartAtIndex(1);
        query.setEndAtIndex(MAXIMUM_TOPSTORIES - 1);
        
        try {
            broker = ServiceLocator.getInstance().findBroker();
            results = (Collection) broker.getCollectionByQuery(query);
        } catch (ServiceLocatorException e) {
            log.error("PersistenceBrokerException thrown in StoryDAO.findTopStory(): " + e.toString());
            throw new DataAccessException("Error in StoryDAO.findTopStory(): " + e.toString(),e);
        } finally {
            if (broker != null) broker.close();
        }
        
        log.info("************Done with the StoryDAO.findTopStory()***************");
        return results;
    }
    
    /**
     * Inserts a single story record into the database.
     *
     * @see com.wrox.javaedge.common.DataAccessObject#insert(com.wrox.javaedge.common.ValueObject)
     */
    public void insert(ValueObject insertRecord) throws DataAccessException {
        log.info("************Entering the StoryDAO.insert()***************");
        PersistenceBroker broker = null;
        try {
            StoryVO storyVO = (StoryVO) insertRecord;
            
            broker = ServiceLocator.getInstance().findBroker();
            broker.beginTransaction();
            broker.store(storyVO);
            broker.commitTransaction();
            
        } catch (PersistenceBrokerException e) {
            // if something went wrong: rollback
            broker.abortTransaction();
            log.error("PersistenceBrokerException thrown in StoryDAO.insert(): " + e.toString());
            e.printStackTrace();
            
            throw new DataAccessException("Error in StoryDAO.insert(): " + e.toString(),e);
        } catch (ServiceLocatorException e) {
            log.error("ServiceLocatorException thrown in StoryDAO.insert(): " + e.toString());
            throw new DataAccessException("ServiceLocatorException thrown in StoryDAO.insert()",e);
        } finally {
            if (broker != null)
                broker.close();
        }
        
        log.info("************Done with the StoryDAO.insert()***************");
    }
    
    /**
     *   Deletes a single record from the story table using OJB.
     */
    public void delete(ValueObject deleteRecord) throws DataAccessException {
        log.info("************Entering the StoryDAO.delete()***************");
        PersistenceBroker broker = null;
        
        try {
            broker = ServiceLocator.getInstance().findBroker();
            StoryVO storyVO = (StoryVO) deleteRecord;
            
            //Begin the transaction.
            broker.beginTransaction();
            broker.delete(storyVO);
            broker.commitTransaction();
        } catch (PersistenceBrokerException e) {
            // if something went wrong: rollback
            broker.abortTransaction();
            log.error("PersistenceBrokerException thrown in StoryDAO.delete(): " + e.toString());
            e.printStackTrace();
            
            throw new DataAccessException("Error in StoryDAO.delete()", e);
        } catch (ServiceLocatorException e) {
            throw new DataAccessException("ServiceLocator exception in StoryDAO.delete()",e);
        } finally {
            if (broker != null) broker.close();
        }
        
        log.info("************Done with the StoryDAO.delete()***************");
    }
    
    
    /**
     *   Updates a single record from the story table using OJB.
     */
    public void update(ValueObject updateRecord) throws DataAccessException {
        log.info("************Entering the StoryDAO.update()***************");
        PersistenceBroker broker = null;
        
        try {
            StoryVO storyVO = (StoryVO) updateRecord;
            
            broker = ServiceLocator.getInstance().findBroker();
            broker.beginTransaction();
            broker.store(storyVO);
            broker.commitTransaction();
        } catch (PersistenceBrokerException e) {
            // if something went wrong: rollback
            broker.abortTransaction();
            log.error("PersistenceBrokerException thrown in StoryDAO.update(): " + e.toString());
            e.printStackTrace();
            
            throw new DataAccessException("Error in StoryDAO.update()", e);
        } catch (ServiceLocatorException e) {
            log.error("ServiceLocatorException thrown in StoryDAO.delete(): " + e.toString());
            throw new DataAccessException("ServiceLocatorException error in StoryDAO.delete()",e);
        } finally {
            if (broker != null) broker.close();
        }
        
        log.info("************Done with the StoryDAO.update()***************");
    }
    
    /**
     * Retrieves all stories in the database as a Collection.
     * Used by Search functionality.
     *
     * @return all stories in the app;
     */
    
    public Collection findAllStories() throws DataAccessException {
        log.info("************Entering the StoryDAO.findAllStories()***************");
        PersistenceBroker broker = null;
        Collection results = null;
        
        try{
            Criteria criteria = new Criteria();
            criteria.addOrderByDescending("storyId");
            
            System.out.println("Critiera:" + criteria.toString());
            
            Query query = QueryFactory.newQuery(StoryVO.class, criteria);
            
            query.setStartAtIndex(1);
            
            //JCC - Jeff why did you put this here.  I was experimenting with the cache originally.  I am going to comment it out.
            //broker.clearCache();
            broker = ServiceLocator.getInstance().findBroker();
            results = (Collection) broker.getCollectionByQuery(query);
        }
        catch (ServiceLocatorException e) {
            log.error("ServiceLocatorException thrown in StoryDAO.findAllStories(): " + e.toString());
            throw new DataAccessException("ServiceLocatorException error in StoryDAO.findAllStories()",e);
        }
        finally {
            if (broker != null) broker.close();
        }
        
        log.info("************Done with StoryDAO.findAllStories()***************");
        
        return results;
        
    }
    
}
