package com.wrox.javaedge.story.ejb;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import com.wrox.javaedge.common.*;
import com.wrox.javaedge.story.*;
import com.wrox.javaedge.member.*;
import com.wrox.javaedge.struts.poststory.*;
import java.util.*;

public interface StoryManager extends EJBObject{
    
    public void addStory(StoryVO storyVO) throws ApplicationException,
    RemoteException;

    public void addStory(PostStoryForm postStoryForm, MemberVO memberVO) throws ApplicationException,
    RemoteException;
    
    public void addComment(StoryVO storyVO, StoryCommentVO storyCommentVO) throws ApplicationException,
    RemoteException;
}
