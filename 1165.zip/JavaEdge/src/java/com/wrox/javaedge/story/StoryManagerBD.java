package com.wrox.javaedge.story;

//import javax.naming.*;
//import javax.rmi.*;
//import java.rmi.*;
//import javax.ejb.*;
import com.wrox.javaedge.common.ApplicationException;
import com.wrox.javaedge.common.DataAccessException;
import com.wrox.javaedge.story.dao.StoryDAO;

/**
 * @todo Need to JavaDoc all of the public methods in this class.
 */
public class StoryManagerBD{

    //**************************************************************************
    // CLASS
    //**************************************************************************
    
    // Create Log4j category instance for logging
    static private org.apache.log4j.Category log = org.apache.log4j.Category.getInstance(StoryManagerBD.class.getName());
    
    //**************************************************************************
    // INSTANCE
    //**************************************************************************
//    StoryManager storyManager = null;
    
    public StoryManagerBD() throws ApplicationException{
/*
        try{
            ServiceLocator serviceLocator = ServiceLocator.getInstance();
            StoryManagerHome storyManagerHome = (StoryManagerHome) serviceLocator.getEJBHome(ServiceLocator.STORYMANAGER);
            storyManager = storyManagerHome.create();
        }
        catch(ServiceLocatorException e){
            System.err.println("A ServiceLocator exception has been raised in StoryManagerBD constructor: " + e.toString());
            throw new ApplicationException("A ServiceLocator exception has been raised in StoryManagerBD constructor: " + e.toString());
        }
        catch(CreateException e){
            System.err.println("A Create exception has been raised in StoryManagerBD constructor: " + e.toString());
            throw new ApplicationException("A Create exception has been raised in StoryManagerBD constructor: " + e.toString());
        }
        catch(RemoteException e){
            System.err.println("A remote exception has been raised in StoryManagerBD constructor: " + e.toString());
            throw new ApplicationException("A remote exception has been raised in StoryManagerBD constructor: " + e.toString());
        }
 */
    }
    
    public void addStory(StoryVO storyVO) throws ApplicationException{
        try{
            StoryDAO storyDAO = new StoryDAO();
            storyDAO.insert(storyVO);
        }
        catch (DataAccessException e){
            throw new ApplicationException("DataAccessException Error in StoryManagerBean.addStory(): " + e.toString(),e);
        }
        
/*        
        try{
            System.out.println("********I AM IN THE STORY MANAGER.addStory()*******");
            storyManager.addStory(storyVO);
            System.out.println("********I AM DONE WITH THE STORY MANAGER.addStory()*******");
        }
        catch(RemoteException e){
            System.err.println("A Remote exception has been raised in StoryManagerBD constructor: " + e.toString());
            throw new ApplicationException("A Remote exception has been raised in StoryManagerBD constructor: " + e.toString());
        }
 */
    }
    
    public void updateStory(StoryVO storyVO) throws ApplicationException{
    	try{
    			 StoryDAO storyDAO = new StoryDAO();
    			 storyDAO.insert(storyVO);
    		 }
    		 catch (DataAccessException e){
    			 throw new ApplicationException("DataAccessException Error in StoryManagerBean.updateStory(): " + e.toString(),e);
    		 }	
    }
    
    public StoryVO retrieveStory(String primaryKey) throws ApplicationException{
    	try{
    				 StoryDAO storyDAO = new StoryDAO();
    				 return (StoryVO) storyDAO.findByPK(primaryKey);
    			 }
    			 catch (DataAccessException e){
    				 throw new ApplicationException("DataAccessException Error in StoryManagerBean.retrieveStory(): " + e.toString(),e);
    			 }	
    }
    
    public void addComment(StoryVO storyVO, StoryCommentVO storyCommentVO) throws ApplicationException{
        log.error("StoryManagerBD.addComment() not implemented!");
/*        
        try{
            storyManager.addComment(storyVO, storyCommentVO);
        }
        catch(RemoteException e){
            System.err.println("A Remote exception has been raised in StoryManagerBD constructor: " + e.toString());
            throw new ApplicationException("A Remote exception has been raised in StoryManagerBD constructor: " + e.toString());
        }
 */
    }
}


