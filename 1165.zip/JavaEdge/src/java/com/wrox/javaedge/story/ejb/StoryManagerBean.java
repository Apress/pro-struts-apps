package com.wrox.javaedge.story.ejb;

import javax.naming.*;
import java.rmi.*;
import com.wrox.javaedge.common.*;
import com.wrox.javaedge.story.*;
import com.wrox.javaedge.member.*; 
import com.wrox.javaedge.story.dao.*;
import com.wrox.javaedge.struts.poststory.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;

public class StoryManagerBean implements SessionBean {
    private SessionContext ctx;
    
    public void setSessionContext(SessionContext sessionCtx) {
        this.ctx = sessionCtx;
    }

    public void addStory(StoryVO storyVO) throws ApplicationException, RemoteException{
        try{
            StoryDAO storyDAO = new StoryDAO();
            storyDAO.insert(storyVO);

            PrizeManager prizeManager = new PrizeManager();
            int numberOfStories = prizeManager.checkStoryCount(storyVO.getStoryAuthor());
            
            boolean TOTAL_COUNT_EQUAL_1000= (numberOfStories==1000);
            boolean TOTAL_COUNT_EQUAL_5000= (numberOfStories==5000);
          
            if (TOTAL_COUNT_EQUAL_1000 || TOTAL_COUNT_EQUAL_5000){
              prizeManager.notifyMarketing(storyVO.getStoryAuthor(), numberOfStories);
            }   
        }
        catch (DataAccessException e){
            throw new ApplicationException("DataAccessException Error in StoryManagerBean.addStory(): " + e.toString(),e);
        }
    }

      
    public void addComment(StoryVO storyVO, StoryCommentVO storyCommentVO)
    throws ApplicationException, RemoteException{
        System.out.println("I AM IN ADD COMMENT");
    }
    
    public void addStory(PostStoryForm postStoryForm, MemberVO memberVO) 
      throws ApplicationException, RemoteException{
      System.out.println("This is an example of Tier Leakage.  I am passing");
      System.out.println("passing an ActionForm class (postStoryForm) to    ");
      System.out.println("EJB.  This creates a tight dependency between the ");
      System.out.println("Struts framework and a piece of business logic. ");
    }

    
    public void ejbCreate() { }
    public void ejbRemove() { }
    public void ejbActivate() { }
    public void ejbPassivate(){ }
}
